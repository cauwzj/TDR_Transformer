clear all
close all
rand('seed',20);

% the length of TDR sensor portions, cable + connection + probe
CableLength=0.3;
SolderLength=0.02;
ProbeLength=0.5;

% some physical constant
LightSpeed=3e08;                   % unit m/s
TimeMeasIntv=3.335640951981520e-11;     % uint s

% cable
L_Cable=3.5714e-07;
C_Cable=6.3492e-11;
R_Cable=0;
G_Cable=0;

% connection
L_Connc=1.5714e-07;
C_Connc=6.3492e-11;
R_Connc=0;
G_Connc=0;

% probe
L_Probe=2.0e-07;
C_Probe_Ori=7.5e-10;
R_Probe=0;
G_Probe=0;

% Source point
InputVoltage=1.0;            % unit V
InputRasingTime=3e-10;              % unit s
CableImped=75;                     % unit ohm
R_Source=75;                       % unit ohm
beta=1/(InputRasingTime);
Vin=CableImped/(R_Source+CableImped)*InputVoltage;

% define the input voltage and its derivative
Vs=@(t) Vin*(1-exp(-beta*t));
dVsdt=@(t) Vin*beta*exp(-beta*t);

% Loading point
R_Loading=10000;

Xdomain=CableLength+SolderLength+ProbeLength;
dx=0.002;
NX=ceil(Xdomain/dx);
XPlot=(0:NX).*dx;
dx=Xdomain/NX;
dt=dx/LightSpeed;
TotalTimeStep=3e3;

No_Cable=floor(CableLength/dx)+1;
No_Connc=floor((CableLength+SolderLength)/dx)+1-No_Cable;
No_Probe=NX-No_Cable-No_Connc;

% Now we made several simulations on the reflection position
NSimu=10000;
RandFactor=rand(NSimu,1);
NWavePoint=1000;
NNd_Er=2;
TimeRflxNNd_Er=zeros(NSimu,NNd_Er);

C_Probe_Res=(0.8333.*RandFactor+0.1667).*C_Probe_Ori*0.75;
C_0=8.854187817e-12*pi/acosh(10);
Er_Res=C_Probe_Res./C_0;

WaveFormData=zeros(NSimu,NWavePoint);
WaveInfoData=zeros(NSimu,NWavePoint);
Wave_Er_Data=zeros(NSimu,NWavePoint);
WaveFormCatg=ones(NSimu,1);

for n_simu=1:NSimu
    
    C_Probe=C_Probe_Res(n_simu,1);
    G_Probe=0;

    L=[L_Cable.*ones(No_Cable,1);L_Connc.*ones(No_Connc,1);L_Probe*ones(No_Probe+1,1)];
    C=[C_Cable.*ones(No_Cable,1);C_Connc.*ones(No_Connc,1);C_Probe*ones(No_Probe+1,1)];
    R=[R_Cable.*ones(No_Cable,1);R_Connc.*ones(No_Connc,1);R_Probe*ones(No_Probe+1,1)];
    G=[G_Cable.*ones(No_Cable,1);G_Connc.*ones(No_Connc,1);G_Probe*ones(No_Probe+1,1)];
% for reflection
    IndexNNd_Er=zeros(NNd_Er,1);
    TimeIndexNNd_Er=zeros(NNd_Er,1);
    IndexNNd_Er(1,1)=No_Cable+No_Connc+1;
    IndexNNd_Er(2,1)=No_Cable+No_Connc+No_Probe+1;

    % -------------- directly solve the equation system ---------------------

    Rs=R_Source;
    Rl=R_Loading;

    Vprev_1=zeros(NX+1,1);
    Vprev_2=zeros(NX+1,1);
    Vcurr=zeros(NX+1,1);
    Coef_A=zeros(NX+1,3);
    Coef_B=zeros(NX+1,1);
    
    WaveFormSimu=zeros(1,TotalTimeStep);
    Scan_Er=zeros(1,TotalTimeStep);
    Scan_Ec=zeros(1,TotalTimeStep);
    Scan_Info=zeros(1,TotalTimeStep);
    Curr_Er=0;
    Curr_Ec=0;
    Curr_Info=0;

    % the differential equation
    for kk=2:NX
%          Coef_A(kk,1)=-0.25*dt^2/dx^2/(L(kk)*C(kk));
%          Coef_A(kk,2)=1+0.5*dt^2/dx^2/(L(kk)*C(kk));
%          Coef_A(kk,3)=-0.25*dt^2/dx^2/(L(kk)*C(kk));
        Coef_A(kk,1)=-0.25/(dx^2);
        Coef_A(kk,2)=L(kk)*C(kk)/(dt^2)+L(kk)*G(kk)/(dt)+0.5/(dx^2);
        Coef_A(kk,3)=-0.25/(dx^2);
    end
    Coef_A(1,2)=1+dt*Rs/L(1)/dx;
    Coef_A(1,3)=-dt*Rs/L(1)/dx;
    Coef_A(NX+1,1)=-dt*Rl/L(NX+1)/dx;
    Coef_A(NX+1,2)=1+dt*Rl/L(NX+1)/dx;

    for T=1:TotalTimeStep

        Vprev_2=Vprev_1;
        Vprev_1=Vcurr;

        for kk=2:NX
%             Coef_B(kk,1)=2*Vprev_1(kk)-Vprev_2(kk)+dt^2/dx^2/(L(kk)*C(kk))*...
%                 (0.5*(Vprev_1(kk+1)+Vprev_1(kk-1)-2*Vprev_1(kk))+...
%                 0.25*(Vprev_2(kk+1)+Vprev_2(kk-1)-2*Vprev_2(kk)));
            Coef_B(kk,1)=2*L(kk)*C(kk)/(dt^2)*Vprev_1(kk)+L(kk)*G(kk)/(dt)*Vprev_1(kk)...
                -L(kk)*C(kk)/(dt^2)*Vprev_2(kk)...
                +1/(dx^2)*(0.5*(Vprev_1(kk+1)+Vprev_1(kk-1)-2*Vprev_1(kk))+...
                0.25*(Vprev_2(kk+1)+Vprev_2(kk-1)-2*Vprev_2(kk)));
        end
        Coef_B(1,1)=Vprev_1(1)+dt*dVsdt(T*dt-dt);
        Coef_B(NX+1,1)=Vprev_1(NX+1);

        Coef_AA=Coef_A;
        Coef_BB=Coef_B;

        % Thomas linear solver    
        for kk=2:NX+1
            ll=Coef_AA(kk,1)/Coef_AA(kk-1,2);
            Coef_AA(kk,2)=Coef_AA(kk,2)-Coef_AA(kk-1,3)*ll;
            Coef_BB(kk,1)=Coef_BB(kk,1)-Coef_BB(kk-1,1)*ll;
        end
        Vcurr(NX+1)=Coef_BB(NX+1,1)/Coef_AA(NX+1,2);
        for kk=NX:-1:1
            Vcurr(kk)=(Coef_BB(kk,1)-Vcurr(kk+1)*Coef_AA(kk,3))/Coef_AA(kk,2);
        end

        for kk=1:NNd_Er
            if TimeIndexNNd_Er(kk,1)==0
                if abs(Vcurr(IndexNNd_Er(kk,1)))>=0.001
                    TimeIndexNNd_Er(kk,1)=T;
                    if kk==1
                        Curr_Info=1;
                    elseif kk==NNd_Er
                        Curr_Info=0;
                    end
                    if kk<NNd_Er
                        Curr_Er=Er_Res(n_simu,kk);
                    elseif kk==NNd_Er
                        Curr_Er=0;
                    end 
                end
            end
        end
        
        Scan_Er(T)=Curr_Er;
        Scan_Info(T)=Curr_Info;
        WaveFormSimu(T)=Vcurr(1);
    end
    %WaveFormSimu=log10(WaveFormSimu);
%    Time=(1:T).*dt;
    WaveFormSimu=(WaveFormSimu-0.5*Vin)./(0.5*Vin);
%     plot(WaveFormSimu)
%    Time=[0,Time];
    WaveFormSimu=[-1,WaveFormSimu];
    Scan_Info=[0,reshape([Scan_Info;Scan_Info],[1,2*T])];
    Scan_Er=[0,reshape([Scan_Er;Scan_Er],[1,2*T])];
    
    WaveFormData(n_simu,:)=WaveFormSimu(1:3:T);
    WaveInfoData(n_simu,:)=Scan_Info(1:3:T);
    Wave_Er_Data(n_simu,:)=Scan_Er(1:3:T);
%    Wave_Ec_Data(n_simu,:)=Scan_Ec(1:T/3);
    
    
    TimeRflxNNd_Er(n_simu,:)=2.*TimeIndexNNd_Er./3;  
end


xlswrite('Er_0_WaveForm.xlsx',WaveFormData);
xlswrite('Er_0_Info.xlsx',WaveInfoData);
xlswrite('Er_0_Er.xlsx',Wave_Er_Data);
%xlswrite('00_Ec.xlsx',Wave_Ec_Data);
